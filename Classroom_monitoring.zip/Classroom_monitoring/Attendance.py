import pylab
import time
import xlrd 
from openpyxl import load_workbook
def Attendance(names):
     now=time.localtime()
     date=str(now[2])+"/"+str(now[1])
     hrs= now[3]
     if hrs<12:
           end="AM"
     elif hrs>12:
           end="PM"
           hrs=int(hrs)-12
     else:
           end="PM"
     timing=str(hrs)+":"+str(now[4])+str(end)
     info=[date,timing]
     for name in names:
          info.append(name)
          
##     info=[date,timing,names]
     wb = load_workbook("attend.xlsx")
     sheet = wb.worksheets[0]

     row_count = sheet.max_row
     column_count = sheet.max_column
     count=(len(info)-column_count)+1
     print(count)
     #print(row_count,column_count)
     for i in range(1,column_count+count):
          sheet.cell(row=row_count+1, column=i).value = info[i-1]
     wb.save('attend.xlsx')
##          read_file()
def get_details(Name):
	
	info=[date,timing,Name]
	return info
def read_file():
	# Give the location of the file 
	Attendance=list()
	loc = ("attend.xlsx") 
	wb = xlrd.open_workbook(loc) 
	sheet = wb.sheet_by_index(0) 
	for i in range(1,sheet.nrows):
		print(sheet.row_values(i)) 
		Attendance.append(sheet.row_values(i))
	return Attendance
if __name__=="__main__":
##	 Attendance(['1','naveen','3'])
##	 time.sleep(2)
	 attend=read_file()
