import RPi.GPIO as gpio
import spidev
import time,os
gpio.setmode(gpio.BCM)
gpio.setup(21,gpio.OUT)
gpio.setup(20,gpio.OUT)
gpio.setup(17, gpio.IN, pull_up_down=gpio.PUD_UP)  
spi = spidev.SpiDev()
spi.open(0,0)

def ReadChannel(channel):
  adc = spi.xfer2([1,(8+channel)<<4,0])
  data = ((adc[1]&3) << 8) + adc[2]
  return data

def ConvertVolts(data,places):
  volts = (data * 3.3)*100 / float(1023)
  volts = round(volts,places)
  return volts
count=0
try:  
  while True:
    temp = ReadChannel(0)
  ##  temp = ConvertVolts(temp_level,2)
    print ("Temp: ",temp)
    time.sleep(1)
    ldr = ReadChannel(1)
    pt = ReadChannel(2)/3
    ct = ReadChannel(3)/100.0
    f=open('/home/pi/log1.txt','w')
    f.write("Total Power Conseption:"+str(pt*ct))
    f.close()
  ##  ldr = ConvertVolts(ldr,2)
    print('ldr=',ldr)
    print('voltage=',pt)
    print('current=',ct)
    if(gpio.input(17)==1):
      print('pir ditected')
      if(temp>50):
        print('fan on')
        gpio.output(20,1)
      else:
        print('fan off')
        gpio.output(20,0)
      if(ldr<30):
        print('bulb on')
        gpio.output(21,1)
      else:
        print('bulb off')
        gpio.output(21,0)
    else:
      print"not"
      gpio.output(20,0)
      gpio.output(21,0)
    time.sleep(1)
except:
  gpio.cleanup()
